# 匿名聊天室项目

### 聊天室地址：

[https://bee-chat.herokuapp.com](https://bee-chat.herokuapp.com)

### 效果图
![](https://chenyueqin1010.github.io/bee-chat/demo/1.png =400)
![](https://chenyueqin1010.github.io/bee-chat/demo/2.png =400)
![](https://chenyueqin1010.github.io/bee-chat/demo/3.png =400)
![](https://chenyueqin1010.github.io/bee-chat/demo/4.png =400)
![](https://chenyueqin1010.github.io/bee-chat/demo/5.png =400)
![](https://chenyueqin1010.github.io/bee-chat/demo/6.png =400)
