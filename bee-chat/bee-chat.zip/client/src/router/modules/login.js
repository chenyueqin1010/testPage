const router = [{
	path: '/login',
	name: 'Login',
	component: () => import('@/views/Login.vue')
}];

export default router;