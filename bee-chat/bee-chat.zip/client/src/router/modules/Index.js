const router = [{
	path: '/',
	name: 'Index',
	component: () => import('@/views/Index.vue')
}];

export default router;