export const getUserInfoStore = defineStore('userInfo', {
	state: () => ({
		userInfo: {}
	})
});
